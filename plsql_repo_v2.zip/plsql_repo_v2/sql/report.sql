-- report.sql
-- Demonstrates BULK COLLECT and FORALL for summary reporting
SET SERVEROUTPUT ON
DECLARE
  TYPE emp_id_tab IS TABLE OF employees.employee_id%TYPE;
  TYPE salary_tab IS TABLE OF employees.salary%TYPE;

  v_emp_ids emp_id_tab;
  v_salaries salary_tab;
  v_avg NUMBER;
BEGIN
  SELECT employee_id, salary BULK COLLECT INTO v_emp_ids, v_salaries FROM employees;

  v_avg := 0;
  FOR i IN 1..v_salaries.COUNT LOOP
    v_avg := v_avg + v_salaries(i);
  END LOOP;
  v_avg := v_avg / v_salaries.COUNT;

  DBMS_OUTPUT.PUT_LINE('Total Employees: ' || v_emp_ids.COUNT);
  DBMS_OUTPUT.PUT_LINE('Average Salary: ' || ROUND(v_avg,2));

  -- Give 5% raise to all salaries using FORALL
  FORALL i IN INDICES OF v_emp_ids
    UPDATE employees SET salary = salary * 1.05 WHERE employee_id = v_emp_ids(i);

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('5% salary increase applied successfully.');
END;
/