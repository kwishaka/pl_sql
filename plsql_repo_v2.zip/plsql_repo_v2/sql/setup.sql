-- setup.sql
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE employees CASCADE CONSTRAINTS';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

CREATE TABLE employees (
  employee_id NUMBER PRIMARY KEY,
  first_name  VARCHAR2(50),
  last_name   VARCHAR2(50),
  department_id NUMBER,
  city VARCHAR2(50),
  salary NUMBER
);

INSERT INTO employees (employee_id, first_name, last_name, department_id, city, salary)
VALUES (100, 'Alice', 'Smith', 1, 'Kigali', 5000);
INSERT INTO employees (employee_id, first_name, last_name, department_id, city, salary)
VALUES (101, 'John', 'Doe', 1, 'Musanze', 5200);
INSERT INTO employees (employee_id, first_name, last_name, department_id, city, salary)
VALUES (102, 'Mary', 'Johnson', 2, 'Butare', 6000);
INSERT INTO employees (employee_id, first_name, last_name, department_id, city, salary)
VALUES (103, 'Bob', 'Brown', 3, 'Kigali', 4800);
COMMIT;
